---
id: DEC-003
title: sysmlpy is pinned exactly
summary: The parser depends on grammar internals, so sysmlpy is pinned to 0.96.4 and a bump is a dialect decision with a test.
date: 2026-11-05
status: accepted
layers: [implementation]
state: 03-implementation/sysmlpy-pin.md
artifacts: []
supersedes: []
superseded_by: []
related: [DEC-001]
---

## Context

The parser reads the raw ANTLR tree through `sysmlpy.antlr_parser.parse` and
walks grammar context classes for port direction, endpoints, multiplicity,
supertypes, and variation. None of that is public API, so a minor release can
change a captured value without a breaking-change note.

## Decision

The dependency is `sysmlpy==0.96.4`, exact. A bump lands as a dialect decision:
a record, a full fixture run, and a test for every behaviour that moved.

## Rationale

A range would let an install pick a grammar that silently changes a parsed
value, and the failure would surface as a wrong artifact downstream rather than
as an import error here. The pin makes the upgrade explicit and testable.

## Alternatives Considered

- `sysmlpy>=0.96,<0.97`. Patch releases still touch the grammar, so the same
  silent drift remains.
- Vendoring the grammar. It removes the pin problem but adds a large maintained
  fork and a second grammar to keep current.

## Consequences

Security and bug fixes from upstream arrive only through a deliberate bump. Both
implementers inherit the pin by depending on this package, so they cannot drift
apart on the grammar.

## Verification

The pin test asserts the exact requirement string in `pyproject.toml`. A bump
pull request adds a test for each touchpoint it changed and reruns every
committed fixture.

## Review Trigger

An upstream fix is needed for a document the dialect must accept, or a
touchpoint in the pin leaf stops existing.
