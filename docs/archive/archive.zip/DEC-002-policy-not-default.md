---
id: DEC-002
title: Domain selection is an explicit policy
summary: RolePolicy, DialectPolicy, and ControlAttributes replace hard-coded markers, are keyword-only, and have no generic default.
date: 2026-11-05
status: accepted
layers: [architecture, implementation]
state: 02-architecture/model-and-policy.md
artifacts: []
supersedes: []
superseded_by: []
related: [DEC-001]
---

## Context

The SSP library hard-coded its markers. Configuration capture, variation
resolution, and the parameter dialect imported `SSP_MODEL_MARKER` and called
`is_ssp_model` directly, so the same code could not read another domain even
though the constructs were generic.

## Decision

Three objects carry the domain: `RolePolicy` for model, analysis, and
experiment recognition; `DialectPolicy` for roles plus metadata recognizers and
rejection flags; `ControlAttributes` for the attribute prefix and retired map.
Public entry points in `parameters/` and `parameters/dialect/` take the policy
keyword-only and required. Marker names stay exported as defaults, and
`SSP_ROLES`/`SSP_POLICY` are the default instances. No `GENERIC_POLICY` ships.

## Rationale

A required keyword makes every call site state which dialect it reads, so a
silent wrong default cannot happen. A generic policy would look like a default
and would hide the domain exactly where the choice matters.

## Alternatives Considered

- A module-level global policy set at import. It reintroduces hidden state and
  breaks two domains in one process.
- An optional policy defaulting to SSP. Convenient, but a generic caller then
  reads SSP semantics without asking for them.

## Consequences

Call sites get longer and private helpers must forward the policy. In exchange,
a custom prefix works end to end, and a second domain needs no edit below
`metadata/`.

## Verification

A test constructs `ControlAttributes(prefix="acme_")` and drives it through
composition and validation. A static layering test rejects a marker import or a
direct `is_ssp_model` call below `metadata/`.

## Review Trigger

A domain needs a different marker vocabulary, or a call site cannot name its
domain because the policy is not reachable there.
