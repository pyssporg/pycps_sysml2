---
id: DEC-001
title: pycps_sysml2 owns the SysML dialect
summary: Parsing, the IR, and every marker and metadata accessor move into one library that pyssp_sysml2 and pyfmi_sysml2 implement.
date: 2026-11-05
status: accepted
layers: [intent]
state: 00-intent/intent.md
artifacts: []
supersedes: []
superseded_by: []
related: [DEC-002]
---

## Context

SysML knowledge was about to live in two places. The SSP library already parsed
SysML and carried the marker vocabulary, and the coming FMI library would need
the same parse, the same IR, and the same `FmuMetadata` accessor. Two copies
drift, and the second copy is discovered only when the two disagree.

## Decision

`pycps_sysml2` is the single home of the dialect: parsing, the IR, variation,
selection, constraints, and every marker and metadata accessor for the SSP and
the FMI dialects. `pyssp_sysml2` and `pyfmi_sysml2` implement the dialect and
emit artifacts; neither keeps a parser or a marker set of its own.

## Rationale

A marker change then lands once, in one release, and both implementers pick it
up. The implementers keep their own release cadence and their own artifact
dependencies, which is why the dialect is a library rather than a package inside
the SSP one.

## Alternatives Considered

- Keep the marker vocabulary in each implementer and share only a parser. Two
  vocabularies still drift, and the FMI markers have no SSP home.
- One monorepo for dialect and artifacts. It couples artifact releases to the
  grammar pin and blocks an implementer from releasing alone.

## Consequences

Both implementers take a hard dependency on this package and must pin a
released wheel. The dialect seam becomes a policy object, so the domain is
selected per call rather than per install.

## Verification

The layering test forbids `pyssp_standard` and `pyssp_sysml2` imports in
`src/`; the intent leaf states the ownership; the implementers' module maps
name this package as their only SysML source.

## Review Trigger

A third dialect arrives that is neither SSP nor FMI, or an implementer needs a
marker this library will not carry.
