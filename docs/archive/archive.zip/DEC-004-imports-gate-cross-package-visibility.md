---
id: DEC-004
title: Imports gate cross-package visibility
summary: A qualified definition is visible only if its package is imported; unknown targets stay a loader-untouched concern for analyze.
date: 2026-11-05
status: accepted
layers: [architecture, implementation]
state: 02-architecture/model-and-policy.md
artifacts: []
supersedes: []
superseded_by: []
related: [DEC-001]
---

## Context

SysML source may `private import` a package's members. The loader previously ignored these statements and resolved any qualified definition by name, regardless of whether the source imported its package. That made cross-package name collisions invisible and let a model reference a definition without declaring its dependency.

## Decision

Import declarations gate cross-package visibility. The parser extracts them as plain data; `Architecture.imports` maps each imported package to its members (`None` for `::*`). A qualified definition is reachable only if its package is imported (wildcard or the named member), and a bare-name fallback searches only visible qualified definitions. An explicit reference to a non-imported package's definition raises with a `private import` hint. Visibility is architecture-wide rather than per importing file, a deliberate simplification until scopes are modelled. Unknown targets are not validated: a missing package remains an `analyze` concern.

## Rationale

Without this rule, a model could silently depend on a package it never declared. Gating resolution on the import map makes the dependency explicit and the failure mode a clear `ValueError` rather than a wrong artifact downstream. Collecting imports per file (not from the merged model) is necessary because sysmlpy's package merge keeps only the first file's imports.

## Alternatives Considered

- Continue ignoring imports and resolve all qualified names. Leaves the original silent-dependency problem.
- Per-file scoping. More faithful to SysML, but the IR carries no per-file origin after merge and the simplification is acceptable until scopes are real.
- Reject unknown targets at load. Makes the loader validating; the boundary already leaves unresolved references to later consumers.

## Consequences

A model must declare `private import Pkg::*;` (or specific members) to use a definition from another package. Existing fixtures and core-definition users gain those imports. A qualified reference to an unimported package now raises instead of resolving, so the error names the member, its owner, and the suggested import. The collected imports are deterministic and duplicate declarations merge without error.

## Verification

`tests/test_package_imports.py` covers invisibility without an import, wildcard and member visibility, own-package access, the non-imported-package `ValueError` with the import hint, and wildcard/member coexistence. The full suite stays green.

## Review Trigger

SysML scopes become part of the IR and per-file visibility becomes expressible, or a consumer needs a name that the architecture-wide map cannot represent.
